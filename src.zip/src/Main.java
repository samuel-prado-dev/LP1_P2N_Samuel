import modelo.*;
import servico.*;

public class Main {
    public static void main(String[] args) {
        // Criando instâncias de Cachorro e Gato
        Animal cachorro = new Cachorro("Rex", 3);
        Animal gato = new Gato("Miau", 2);

        // Criando o serviço de animais
        AnimalService animalService = new AnimalService();

        // Adicionando animais ao serviço
        animalService.adicionarAnimal(cachorro);
        animalService.adicionarAnimal(gato);

        // Emitindo os sons de todos os animais
        animalService.emitirSons();

        // Usando a classe Pessoa (record) como exemplo
        Pessoa pessoa = new Pessoa("João", 25);
        System.out.println("Pessoa: " + pessoa);
    }
}