package servico;

import modelo.Animal;
import modelo.Cachorro;
import modelo.Gato;
import java.util.ArrayList;
import java.util.List;

public class AnimalService {

    private final List<Animal> animais = new ArrayList<>();

    // Método para adicionar um animal à lista
    public void adicionarAnimal(Animal animal) {
        animais.add(animal);
    }

    // Método para emitir o som de todos os animais
    public void emitirSons() {
        animais.forEach(Animal::fazerSom); // Polimorfismo
    }
}