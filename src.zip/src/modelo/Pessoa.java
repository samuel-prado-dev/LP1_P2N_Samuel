package modelo;

public record Pessoa(String nome, int idade) {
    // O Java cria automaticamente os getters, equals, hashCode e toString para records
}