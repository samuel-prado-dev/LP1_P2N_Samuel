package modelo;

public abstract class Animal implements FazSom {
    private final String nome;
    private final int idade;

    // Construtor
    public Animal(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    // Métodos getters
    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    // Método abstrato
    public abstract void emitirSom();
}