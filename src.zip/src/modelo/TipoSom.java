package modelo;

public enum TipoSom {
    LATIDO, MIADO, OUTRO
}