package modelo;

public interface FazSom {
    void fazerSom();
}